/* host.jsx — SubAI Cloud Plugin v1.2 — Track Selection + Smart Import */

function _ok(o) {
    var r = { ok: true };
    for (var k in o) r[k] = o[k];
    return JSON.stringify(r);
}
function _er(m) { return JSON.stringify({ ok: false, e: String(m) }); }

function _seq() {
    var s = null;
    try { s = app.project.activeSequence; } catch(e) {}
    if (!s) {
        try {
            if (app.project.sequences && app.project.sequences.numSequences > 0)
                s = app.project.sequences[0];
        } catch(e) {}
    }
    return s;
}

function getSeq() {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף פעיל — דאבל-קליק על רצף בפאנל Project");
        var tb  = parseFloat(s.timebase) || 1;
        var dur = parseFloat(s.end) / tb;
        if (isNaN(dur) || dur <= 0) dur = 0;

        var i = 0, o = dur, BIG = 4503599627370000;
        try { var t = s.getInPointAsTime();  if (t && typeof t.seconds !== 'undefined' && t.seconds >= 0 && t.seconds < dur) i = t.seconds; } catch(e) {}
        try { var t = s.getOutPointAsTime(); if (t && typeof t.seconds !== 'undefined' && t.seconds > 0 && t.seconds <= dur) o = t.seconds; } catch(e) {}

        if (i === 0 && o === dur) {
            try { var r = parseFloat(s.getInPoint()); if (!isNaN(r) && r > 0 && r < BIG) { var v = r / 254016000000; i = (v < dur) ? v : r / tb; if (i >= dur) i = 0; } } catch(e) {}
            try { var r = parseFloat(s.getOutPoint()); if (!isNaN(r) && r > 0 && r < BIG) { var v = r / 254016000000; o = (v <= dur * 1.1) ? v : r / tb; if (o > dur) o = dur; } } catch(e) {}
        }
        if (o <= i) { i = 0; o = dur; }

        var fps = 25;
        try { var st = s.getSettings(); if (st.videoFrameRate && st.videoFrameRate.seconds > 0) fps = Math.round(1 / st.videoFrameRate.seconds); } catch(e) {}
        var hasWA = (o - i) > 0.5 && (i > 0.5 || (dur - o) > 0.5);

        return _ok({ name: s.name || "רצף", dur: Math.round(dur*1000)/1000, fps: fps,
            i: Math.round(i*1000)/1000, o: Math.round(o*1000)/1000, hasWA: hasWA });
    } catch(e) { return _er(e.toString()); }
}

/* ── Refresh In/Out ── */
function getInOut() {
    try {
        var s = _seq(); if (!s) return _er("no seq");
        var tb = parseFloat(s.timebase) || 1;
        var dur = parseFloat(s.end) / tb;
        var i = 0, o = dur, BIG = 4503599627370000;
        try { var t = s.getInPointAsTime(); if (t && t.seconds >= 0 && t.seconds < dur) i = t.seconds; } catch(e) {}
        try { var t = s.getOutPointAsTime(); if (t && t.seconds > 0 && t.seconds <= dur) o = t.seconds; } catch(e) {}
        if (i === 0 && o === dur) {
            try { var r = parseFloat(s.getInPoint()); if (r > 0 && r < BIG) { var v = r / 254016000000; i = (v < dur) ? v : r / tb; if (i >= dur) i = 0; } } catch(e) {}
            try { var r = parseFloat(s.getOutPoint()); if (r > 0 && r < BIG) { var v = r / 254016000000; o = (v <= dur * 1.1) ? v : r / tb; if (o > dur) o = dur; } } catch(e) {}
        }
        if (o <= i) { i = 0; o = dur; }
        var hasWA = (o - i) > 0.5 && (i > 0.5 || (dur - o) > 0.5);
        return _ok({ i: Math.round(i*1000)/1000, o: Math.round(o*1000)/1000, hasWA: hasWA, dur: Math.round(dur*1000)/1000 });
    } catch(e) { return _er(e.toString()); }
}

/* ── Get audio tracks info (#10) ── */
function getAudioTracks() {
    try {
        var s = _seq();
        if (!s) return _er("no seq");
        var tracks = [];
        for (var t = 0; t < s.audioTracks.numTracks; t++) {
            var track = s.audioTracks[t];
            var clipCount = 0;
            var clipNames = [];
            try {
                clipCount = track.clips.numItems;
                for (var c = 0; c < Math.min(track.clips.numItems, 3); c++) {
                    try { clipNames.push(track.clips[c].name); } catch(e) {}
                }
            } catch(e) {}
            tracks.push({
                index: t,
                name: track.name || ("A" + (t + 1)),
                muted: track.isMuted(),
                clipCount: clipCount,
                clipNames: clipNames
            });
        }
        return _ok({ tracks: tracks });
    } catch(e) { return _er(e.toString()); }
}

/* ── Mute/unmute specific audio tracks (#10) ── */
function setTrackMute(trackIndex, mute) {
    try {
        var s = _seq();
        if (!s) return _er("no seq");
        if (trackIndex < 0 || trackIndex >= s.audioTracks.numTracks) return _er("invalid track");
        var track = s.audioTracks[trackIndex];
        track.setMute(mute ? 1 : 0);
        return _ok({ index: trackIndex, muted: mute });
    } catch(e) { return _er(e.toString()); }
}

/* ── Mute all tracks except selected one (#10) ── */
function soloAudioTrack(soloIndex) {
    try {
        var s = _seq();
        if (!s) return _er("no seq");
        var originalStates = [];
        for (var t = 0; t < s.audioTracks.numTracks; t++) {
            originalStates.push(s.audioTracks[t].isMuted());
            s.audioTracks[t].setMute(t === soloIndex ? 0 : 1);
        }
        return _ok({ solo: soloIndex, originalStates: originalStates });
    } catch(e) { return _er(e.toString()); }
}

/* ── Restore original mute states (#10) ── */
function restoreTrackMutes(statesJson) {
    try {
        var s = _seq();
        if (!s) return _er("no seq");
        var states = JSON.parse(statesJson);
        for (var t = 0; t < Math.min(states.length, s.audioTracks.numTracks); t++) {
            s.audioTracks[t].setMute(states[t] ? 1 : 0);
        }
        return _ok({});
    } catch(e) { return _er(e.toString()); }
}

/* ── Preset scanner ── */
function _scanEPR(folder, depth, results) {
    if (depth > 3 || !folder || !folder.exists) return;
    var items = folder.getFiles(); if (!items) return;
    for (var i = 0; i < items.length; i++) {
        var it = items[i];
        if (it instanceof File && it.name.match(/\.epr$/i)) results.push(it.fsName);
        else if (it instanceof Folder && depth < 3) _scanEPR(it, depth + 1, results);
    }
}
function _pickAudioPreset(list) {
    var pri = [/wav/i, /aiff/i, /audio/i, /flac/i, /mp3/i, /match.?source/i];
    for (var p = 0; p < pri.length; p++)
        for (var i = 0; i < list.length; i++)
            if (pri[p].test(list[i])) return list[i];
    return list.length > 0 ? list[0] : "";
}
function findPreset(custom) {
    if (custom) { var f = new File(custom); if (f.exists) return custom; }
    var all = [];
    try { var sp = new Folder(app.path + "/MediaIO/systempresets"); if (sp.exists) _scanEPR(sp, 0, all); } catch(e) {}
    try { var b = new Folder(app.path); if (b.parent) { var sp2 = new Folder(b.parent.fsName + "/MediaIO/systempresets"); if (sp2.exists) _scanEPR(sp2, 0, all); } } catch(e) {}
    var dirs = ["C:/Program Files/Adobe","C:/Program Files (x86)/Adobe","D:/Program Files/Adobe"];
    for (var d = 0; d < dirs.length; d++) {
        try { var af = new Folder(dirs[d]); if (!af.exists) continue;
            var subs = af.getFiles(); for (var s = 0; s < subs.length; s++) {
                if (subs[s] instanceof Folder && subs[s].name.match(/premiere/i)) {
                    var sp = new Folder(subs[s].fsName+"/MediaIO/systempresets"); if (sp.exists) _scanEPR(sp,0,all); }}} catch(e) {}
    }
    return _pickAudioPreset(all);
}

/* ── Export audio ── */
function exportAudio(outPath, presetPath, workOnly) {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף פעיל");
        var preset = findPreset(presetPath);
        var mode = workOnly ? 2 : 1;
        var tried = [];

        if (preset) {
            try { s.exportAsMediaDirect(outPath, preset, mode);
                var f = new File(outPath); if (f.exists && f.length > 100) return _ok({path:outPath, m:"direct", mode:mode});
                tried.push("direct+preset: empty"); } catch(e) { tried.push("direct+preset: " + e.toString().substring(0,60)); }
        }
        try { s.exportAsMediaDirect(outPath, "", mode);
            var f = new File(outPath); if (f.exists && f.length > 100) return _ok({path:outPath, m:"direct_default", mode:mode});
            tried.push("direct_default: empty"); } catch(e) { tried.push("direct_default: " + e.toString().substring(0,60)); }

        if (preset) {
            try { app.encoder.launchEncoder();
                app.encoder.encodeSequence(s, outPath, preset, workOnly?app.encoder.ENCODE_WORK_AREA:app.encoder.ENCODE_ENTIRE, true);
                return _ok({path:outPath, m:"ame", async:true}); } catch(e) { tried.push("ame: " + e.toString().substring(0,60)); }
        }
        try { app.encoder.launchEncoder();
            app.encoder.encodeSequence(s, outPath, "", workOnly?app.encoder.ENCODE_WORK_AREA:app.encoder.ENCODE_ENTIRE, true);
            return _ok({path:outPath, m:"ame_default", async:true}); } catch(e) { tried.push("ame_default: " + e.toString().substring(0,60)); }

        return _er("ייצוא נכשל.\n" + tried.join("\n"));
    } catch(e) { return _er(e.toString()); }
}

/* ── Import SRT — DIRECT to Caption Track ── */
function importSRT(srtPath, startSec) {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף");
        if (!(new File(srtPath)).exists) return _er("קובץ לא נמצא");

        var startTime = new Time();
        startTime.seconds = parseFloat(startSec) || 0;

        // Import file to project
        var importOk = app.project.importFiles([srtPath], true, app.project.rootItem, false);

        // Find the imported item (search from end — most recently added)
        var item = null;
        var fname = srtPath.split(/[\/\\]/).pop();
        var root = app.project.rootItem;
        for (var i = root.children.numItems - 1; i >= 0; i--) {
            var it = root.children[i];
            if (!it) continue;
            try {
                if (it.getMediaPath && it.getMediaPath().indexOf(fname) !== -1) { item = it; break; }
            } catch(e) {}
            if (it.name === fname || it.name === fname.replace('.srt','')) { item = it; break; }
        }

        if (!item) return _ok({ placed: false, note: "SRT יובא לפרויקט — גרור ל-Caption Track" });

        var tried = [];

        // Method 1: sequence.insertClip (Premiere 2022+)
        // This should auto-detect SRT as caption and place on caption track
        try {
            s.insertClip(item, startTime);
            return _ok({ placed: true, method: "insertClip", time: parseFloat(startSec) || 0 });
        } catch(e1) { tried.push("insertClip: " + e1.toString().substring(0, 50)); }

        // Method 2: overwriteClip on video track 0 (Premiere sometimes routes captions)
        try {
            s.overwriteClip(item, startTime);
            return _ok({ placed: true, method: "overwriteClip", time: parseFloat(startSec) || 0 });
        } catch(e2) { tried.push("overwriteClip: " + e2.toString().substring(0, 50)); }

        // Method 3: insertClip with track indices
        try {
            var vIdx = s.videoTracks.numTracks > 0 ? s.videoTracks.numTracks - 1 : 0;
            var aIdx = s.audioTracks.numTracks > 0 ? s.audioTracks.numTracks - 1 : 0;
            s.insertClip(item, startTime, vIdx, aIdx);
            return _ok({ placed: true, method: "insertClip_idx", time: parseFloat(startSec) || 0 });
        } catch(e3) { tried.push("insertClip_idx: " + e3.toString().substring(0, 50)); }

        // Method 4: Use QE DOM (internal API, more powerful)
        try {
            var qeSeq = qe.project.getActiveSequence();
            if (qeSeq) {
                // Try to add via QE
                var tickTime = startTime.seconds * 254016000000;
                qeSeq.addClip(item, tickTime.toString());
                return _ok({ placed: true, method: "qe_addClip", time: parseFloat(startSec) || 0 });
            }
        } catch(e4) { tried.push("qe: " + e4.toString().substring(0, 50)); }

        // Method 5: Set in/out on item then insert
        try {
            item.setInPoint(0, 4);
            s.insertClip(item, startTime);
            return _ok({ placed: true, method: "setInPoint+insert", time: parseFloat(startSec) || 0 });
        } catch(e5) { tried.push("setIn+insert: " + e5.toString().substring(0, 50)); }

        return _ok({ placed: false, note: "SRT יובא לפרויקט — גרור ל-Caption Track", tried: tried });
    } catch(e) { return _er(e.toString()); }
}
