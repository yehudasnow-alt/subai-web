/* host.jsx — SubAI Cloud Plugin v1.1 — Fixed In/Out Export */

function _ok(o) {
    var r = { ok: true };
    for (var k in o) r[k] = o[k];
    return JSON.stringify(r);
}
function _er(m) { return JSON.stringify({ ok: false, e: String(m) }); }

function _seq() {
    var s = null;
    try { s = app.project.activeSequence; } catch(e) {}
    if (!s) {
        try {
            if (app.project.sequences && app.project.sequences.numSequences > 0)
                s = app.project.sequences[0];
        } catch(e) {}
    }
    return s;
}

function getSeq() {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף פעיל — דאבל-קליק על רצף בפאנל Project");
        var tb  = parseFloat(s.timebase) || 1;
        var dur = parseFloat(s.end) / tb;
        if (isNaN(dur) || dur <= 0) dur = 0;

        // Get In/Out points - try multiple methods
        var i = 0, o = dur;
        var BIG = 4503599627370000;

        // Method 1: getInPointAsTime / getOutPointAsTime
        try {
            var inT = s.getInPointAsTime();
            if (inT && typeof inT.seconds !== 'undefined' && inT.seconds >= 0 && inT.seconds < dur) {
                i = inT.seconds;
            }
        } catch(e) {}
        try {
            var outT = s.getOutPointAsTime();
            if (outT && typeof outT.seconds !== 'undefined' && outT.seconds > 0 && outT.seconds <= dur) {
                o = outT.seconds;
            }
        } catch(e) {}

        // Method 2: getInPoint / getOutPoint (ticks-based)
        if (i === 0 && o === dur) {
            try {
                var inTicks = parseFloat(s.getInPoint());
                if (!isNaN(inTicks) && inTicks > 0 && inTicks < BIG) {
                    i = inTicks / 254016000000;  // ticks to seconds (standard tick rate)
                    if (i >= dur) i = inTicks / tb;  // fallback to timebase
                    if (i >= dur || i < 0) i = 0;
                }
            } catch(e) {}
            try {
                var outTicks = parseFloat(s.getOutPoint());
                if (!isNaN(outTicks) && outTicks > 0 && outTicks < BIG) {
                    o = outTicks / 254016000000;
                    if (o > dur * 1.1) o = outTicks / tb;
                    if (o > dur || o <= 0) o = dur;
                }
            } catch(e) {}
        }

        // Ensure valid range
        if (o <= i) { i = 0; o = dur; }

        var fps = 25;
        try {
            var st = s.getSettings();
            if (st.videoFrameRate && st.videoFrameRate.seconds > 0)
                fps = Math.round(1 / st.videoFrameRate.seconds);
        } catch(e) {}

        // Has work area = In/Out are meaningfully different from full sequence
        var hasWA = (o - i) > 0.5 && (i > 0.5 || (dur - o) > 0.5);

        return _ok({
            name: s.name || "רצף",
            dur: Math.round(dur * 1000) / 1000,
            fps: fps,
            i: Math.round(i * 1000) / 1000,
            o: Math.round(o * 1000) / 1000,
            hasWA: hasWA
        });
    } catch(e) { return _er(e.toString()); }
}

/* ── Refresh In/Out points only (fast, no full reload) ── */
function getInOut() {
    try {
        var s = _seq();
        if (!s) return _er("no seq");
        var tb = parseFloat(s.timebase) || 1;
        var dur = parseFloat(s.end) / tb;
        var i = 0, o = dur, BIG = 4503599627370000;

        try { var t = s.getInPointAsTime();  if (t && t.seconds >= 0 && t.seconds < dur) i = t.seconds; } catch(e) {}
        try { var t = s.getOutPointAsTime(); if (t && t.seconds > 0 && t.seconds <= dur) o = t.seconds; } catch(e) {}

        if (i === 0 && o === dur) {
            try { var r = parseFloat(s.getInPoint()); if (r > 0 && r < BIG) { var v = r / 254016000000; i = (v < dur) ? v : r / tb; if (i >= dur) i = 0; } } catch(e) {}
            try { var r = parseFloat(s.getOutPoint()); if (r > 0 && r < BIG) { var v = r / 254016000000; o = (v <= dur * 1.1) ? v : r / tb; if (o > dur) o = dur; } } catch(e) {}
        }

        if (o <= i) { i = 0; o = dur; }
        var hasWA = (o - i) > 0.5 && (i > 0.5 || (dur - o) > 0.5);
        return _ok({ i: Math.round(i*1000)/1000, o: Math.round(o*1000)/1000, hasWA: hasWA, dur: Math.round(dur*1000)/1000 });
    } catch(e) { return _er(e.toString()); }
}

/* ── Preset scanner ── */
function _scanEPR(folder, depth, results) {
    if (depth > 3 || !folder || !folder.exists) return;
    var items = folder.getFiles(); if (!items) return;
    for (var i = 0; i < items.length; i++) {
        var it = items[i];
        if (it instanceof File && it.name.match(/\.epr$/i)) results.push(it.fsName);
        else if (it instanceof Folder && depth < 3) _scanEPR(it, depth + 1, results);
    }
}
function _pickAudioPreset(list) {
    var pri = [/wav/i, /aiff/i, /audio/i, /flac/i, /mp3/i, /match.?source/i];
    for (var p = 0; p < pri.length; p++)
        for (var i = 0; i < list.length; i++)
            if (pri[p].test(list[i])) return list[i];
    return list.length > 0 ? list[0] : "";
}
function findPreset(custom) {
    if (custom) { var f = new File(custom); if (f.exists) return custom; }
    var all = [];
    try { var sp = new Folder(app.path + "/MediaIO/systempresets"); if (sp.exists) _scanEPR(sp, 0, all); } catch(e) {}
    try { var b = new Folder(app.path); if (b.parent) { var sp2 = new Folder(b.parent.fsName + "/MediaIO/systempresets"); if (sp2.exists) _scanEPR(sp2, 0, all); } } catch(e) {}
    var dirs = ["C:/Program Files/Adobe","C:/Program Files (x86)/Adobe","D:/Program Files/Adobe"];
    for (var d = 0; d < dirs.length; d++) {
        try { var af = new Folder(dirs[d]); if (!af.exists) continue;
            var subs = af.getFiles(); for (var s = 0; s < subs.length; s++) {
                if (subs[s] instanceof Folder && subs[s].name.match(/premiere/i)) {
                    var sp = new Folder(subs[s].fsName+"/MediaIO/systempresets"); if (sp.exists) _scanEPR(sp,0,all); }}} catch(e) {}
    }
    return _pickAudioPreset(all);
}

/* ── Export audio — with proper In/Out support ── */
function exportAudio(outPath, presetPath, workOnly) {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף פעיל");
        var preset = findPreset(presetPath);

        // workOnly: true = export work area (In/Out), false = entire sequence
        // exportAsMediaDirect mode: 1 = entire, 2 = work area
        var mode = workOnly ? 2 : 1;
        var tried = [];

        // Strategy 1: Direct with preset + work area mode
        if (preset) {
            try {
                s.exportAsMediaDirect(outPath, preset, mode);
                var f = new File(outPath);
                if (f.exists && f.length > 100) return _ok({path:outPath, m:"direct", mode:mode});
                tried.push("direct+preset(mode=" + mode + "): empty");
            } catch(e) { tried.push("direct+preset: " + e.toString().substring(0,60)); }
        }

        // Strategy 2: Direct without preset
        try {
            s.exportAsMediaDirect(outPath, "", mode);
            var f = new File(outPath);
            if (f.exists && f.length > 100) return _ok({path:outPath, m:"direct_default", mode:mode});
            tried.push("direct_default(mode=" + mode + "): empty");
        } catch(e) { tried.push("direct_default: " + e.toString().substring(0,60)); }

        // Strategy 3: AME with preset
        if (preset) {
            try {
                app.encoder.launchEncoder();
                var ameMode = workOnly ? app.encoder.ENCODE_WORK_AREA : app.encoder.ENCODE_ENTIRE;
                app.encoder.encodeSequence(s, outPath, preset, ameMode, true);
                return _ok({path:outPath, m:"ame", async:true, mode:mode});
            } catch(e) { tried.push("ame: " + e.toString().substring(0,60)); }
        }

        // Strategy 4: AME without preset
        try {
            app.encoder.launchEncoder();
            var ameMode = workOnly ? app.encoder.ENCODE_WORK_AREA : app.encoder.ENCODE_ENTIRE;
            app.encoder.encodeSequence(s, outPath, "", ameMode, true);
            return _ok({path:outPath, m:"ame_default", async:true, mode:mode});
        } catch(e) { tried.push("ame_default: " + e.toString().substring(0,60)); }

        return _er("ייצוא נכשל.\n" + tried.join("\n"));
    } catch(e) { return _er(e.toString()); }
}

/* ── Import SRT ── */
function importSRT(srtPath, startSec) {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף");
        if (!(new File(srtPath)).exists) return _er("קובץ לא נמצא");

        app.project.importFiles([srtPath], true, app.project.rootItem, false);

        var item = null, fname = srtPath.split(/[\/\\]/).pop(), root = app.project.rootItem;
        for (var i = 0; i < root.children.numItems; i++) {
            var it = root.children[i]; if (!it) continue;
            try { if (it.getMediaPath().indexOf(srtPath) !== -1) { item = it; break; } } catch(e) {}
            if (!item && it.name === fname) item = it;
        }
        if (!item) return _ok({ placed: false, note: "SRT יובא לפרויקט — גרור לשורת Caption" });

        // Try to insert at the correct time position
        try {
            var t = new Time();
            t.seconds = parseFloat(startSec) || 0;

            // Try caption track first
            try {
                if (s.captionTracks && s.captionTracks.numTracks > 0) {
                    // Use existing caption track
                }
            } catch(e) {}

            // Insert clip at time
            item.insertClipAt(s, t, false);
            return _ok({ placed: true, time: parseFloat(startSec) || 0 });
        } catch(e) {
            return _ok({ placed: false, note: "SRT יובא לפרויקט — גרור לשורת Caption" });
        }
    } catch(e) { return _er(e.toString()); }
}
