@echo off
chcp 65001 >nul 2>&1
title SubAI - Plugin Installer
color 0B

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║                                              ║
echo  ║          ✨  SubAI Plugin Installer  ✨      ║
echo  ║                                              ║
echo  ║    כתוביות AI לפרימייר פרו                   ║
echo  ║                                              ║
echo  ╚══════════════════════════════════════════════╝
echo.
echo  [1/3] Checking system...
echo.

:: Check if Premiere Pro is installed by looking for CEP extensions folder
set "EXT_DIR=%APPDATA%\Adobe\CEP\extensions"
set "PLUGIN_DIR=%EXT_DIR%\com.subai.cloud.panel"

if not exist "%APPDATA%\Adobe" (
    echo  ❌ Adobe folder not found!
    echo  Make sure Adobe Premiere Pro is installed.
    echo.
    pause
    exit /b 1
)

:: Create CEP extensions folder if needed
if not exist "%EXT_DIR%" (
    echo  Creating extensions folder...
    mkdir "%EXT_DIR%" 2>nul
)

echo  ✅ Adobe folder found: %APPDATA%\Adobe
echo.

:: Enable unsigned extensions (PlayerDebugMode)
echo  [2/3] Configuring Adobe CEP...
echo.

reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1

echo  ✅ Debug mode enabled (required for custom plugins)
echo.

:: Copy plugin files
echo  [3/3] Installing SubAI plugin...
echo.

:: Remove old version if exists
if exist "%PLUGIN_DIR%" (
    echo  Removing previous version...
    rmdir /s /q "%PLUGIN_DIR%" 2>nul
)

:: Get the directory where this installer is located
set "SRC_DIR=%~dp0com.subai.cloud.panel"

if not exist "%SRC_DIR%" (
    echo  ❌ Plugin files not found!
    echo  Make sure 'com.subai.cloud.panel' folder is next to this installer.
    echo.
    pause
    exit /b 1
)

:: Copy plugin
xcopy "%SRC_DIR%" "%PLUGIN_DIR%" /E /I /Y /Q >nul 2>&1

if exist "%PLUGIN_DIR%\index.html" (
    echo  ✅ Plugin installed successfully!
    echo.
    echo  ╔══════════════════════════════════════════════╗
    echo  ║                                              ║
    echo  ║          🎉  Installation Complete!  🎉      ║
    echo  ║                                              ║
    echo  ║  Installed to:                               ║
    echo  ║  %EXT_DIR%                                   ║
    echo  ║                                              ║
    echo  ║  Next steps:                                 ║
    echo  ║  1. Open Premiere Pro                        ║
    echo  ║  2. Window → Extensions → SubAI              ║
    echo  ║  3. Paste your API Key and start!            ║
    echo  ║                                              ║
    echo  ╚══════════════════════════════════════════════╝
) else (
    echo  ❌ Installation failed. Try running as Administrator.
)

echo.
echo  Press any key to close...
pause >nul
