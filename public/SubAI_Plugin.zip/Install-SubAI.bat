@echo off
title SubAI - Plugin Installer
color 0B

echo.
echo  ======================================
echo       SubAI Plugin Installer v1.0
echo       AI Subtitles for Premiere Pro
echo  ======================================
echo.
echo  [1/3] Checking system...

set "EXT_DIR=%APPDATA%\Adobe\CEP\extensions"
set "PLUGIN_DIR=%EXT_DIR%\com.subai.cloud.panel"

if not exist "%APPDATA%\Adobe" (
    echo.
    echo  ERROR: Adobe folder not found!
    echo  Make sure Adobe Premiere Pro is installed.
    echo.
    pause
    exit /b 1
)

if not exist "%EXT_DIR%" (
    mkdir "%EXT_DIR%" 2>nul
)

echo  OK - Adobe folder found
echo.

echo  [2/3] Configuring Adobe CEP...

reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1

echo  OK - Debug mode enabled
echo.

echo  [3/3] Installing plugin...

if exist "%PLUGIN_DIR%" (
    echo  Removing previous version...
    rmdir /s /q "%PLUGIN_DIR%" 2>nul
)

set "SRC_DIR=%~dp0com.subai.cloud.panel"

if not exist "%SRC_DIR%" (
    echo.
    echo  ERROR: Plugin files not found!
    echo  Make sure com.subai.cloud.panel folder
    echo  is in the same folder as this installer.
    echo.
    pause
    exit /b 1
)

xcopy "%SRC_DIR%" "%PLUGIN_DIR%" /E /I /Y /Q >nul 2>&1

if exist "%PLUGIN_DIR%\index.html" (
    echo  OK - Plugin installed!
    echo.
    echo  ======================================
    echo       INSTALLATION COMPLETE!
    echo  ======================================
    echo.
    echo  Next steps:
    echo  1. Open Adobe Premiere Pro
    echo  2. Go to: Window - Extensions - SubAI
    echo  3. Paste your API Key and start!
    echo.
    echo  Get your API Key at:
    echo  https://subai-web.vercel.app/dashboard
    echo.
) else (
    echo.
    echo  ERROR: Installation failed.
    echo  Try right-click - Run as Administrator.
    echo.
)

pause
