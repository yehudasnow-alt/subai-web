/* host.jsx — SubAI Cloud Plugin v1.0 */

function _ok(o) {
    var r = { ok: true };
    for (var k in o) r[k] = o[k];
    return JSON.stringify(r);
}
function _er(m) { return JSON.stringify({ ok: false, e: String(m) }); }

function _seq() {
    var s = null;
    try { s = app.project.activeSequence; } catch(e) {}
    if (!s) {
        try {
            if (app.project.sequences && app.project.sequences.numSequences > 0)
                s = app.project.sequences[0];
        } catch(e) {}
    }
    return s;
}

function getSeq() {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף פעיל — דאבל-קליק על רצף בפאנל Project");
        var tb  = parseFloat(s.timebase) || 1;
        var dur = parseFloat(s.end) / tb;
        if (isNaN(dur) || dur <= 0) dur = 0;
        var BIG = 4503599627370000, i = 0, o = dur;
        try { var t = s.getInPointAsTime();  if (t && t.seconds >= 0 && t.seconds < dur)  i = t.seconds; } catch(e) {}
        try { var t = s.getOutPointAsTime(); if (t && t.seconds >  0 && t.seconds <= dur) o = t.seconds; } catch(e) {}
        if (i === 0) { try { var r = parseFloat(s.getInPoint());  if (r > 0 && r < BIG) i = r / tb; } catch(e) {} }
        if (o === dur) { try { var r = parseFloat(s.getOutPoint()); if (r > 0 && r < BIG && r > i) o = r / tb; } catch(e) {} }
        var fps = 25;
        try { var st = s.getSettings(); if (st.videoFrameRate && st.videoFrameRate.seconds > 0) fps = Math.round(1 / st.videoFrameRate.seconds); } catch(e) {}
        var hasWA = (o - i) > 0.5 && !(i < 0.1 && Math.abs(o - dur) < 0.1);
        return _ok({ name: s.name || "רצף", dur: Math.round(dur*1000)/1000, fps: fps, i: Math.round(i*1000)/1000, o: Math.round(o*1000)/1000, hasWA: hasWA });
    } catch(e) { return _er(e.toString()); }
}

/* ── Preset scanner ────────────────────────────────────── */
function _scanEPR(folder, depth, results) {
    if (depth > 3 || !folder || !folder.exists) return;
    var items = folder.getFiles();
    if (!items) return;
    for (var i = 0; i < items.length; i++) {
        var it = items[i];
        if (it instanceof File && it.name.match(/\.epr$/i)) results.push(it.fsName);
        else if (it instanceof Folder && depth < 3) _scanEPR(it, depth + 1, results);
    }
}

function _pickAudioPreset(list) {
    var pri = [/wav/i, /aiff/i, /audio/i, /flac/i, /mp3/i, /match.?source/i];
    for (var p = 0; p < pri.length; p++)
        for (var i = 0; i < list.length; i++)
            if (pri[p].test(list[i])) return list[i];
    return list.length > 0 ? list[0] : "";
}

function findPreset(custom) {
    if (custom) { var f = new File(custom); if (f.exists) return custom; }
    var all = [];
    try { var sp = new Folder(app.path + "/MediaIO/systempresets"); if (sp.exists) _scanEPR(sp, 0, all); } catch(e) {}
    try { var b = new Folder(app.path); if (b.parent) { var sp2 = new Folder(b.parent.fsName + "/MediaIO/systempresets"); if (sp2.exists) _scanEPR(sp2, 0, all); } } catch(e) {}
    var dirs = ["C:/Program Files/Adobe","C:/Program Files (x86)/Adobe","D:/Program Files/Adobe"];
    for (var d = 0; d < dirs.length; d++) {
        try { var af = new Folder(dirs[d]); if (!af.exists) continue;
            var subs = af.getFiles(); for (var s = 0; s < subs.length; s++) {
                if (subs[s] instanceof Folder && subs[s].name.match(/premiere/i)) {
                    var sp = new Folder(subs[s].fsName+"/MediaIO/systempresets"); if (sp.exists) _scanEPR(sp,0,all); }}} catch(e) {}
    }
    return _pickAudioPreset(all);
}

/* ── Export audio ──────────────────────────────────────── */
function exportAudio(outPath, presetPath, workOnly) {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף פעיל");
        var preset = findPreset(presetPath);
        var mode = workOnly ? 2 : 1;
        var tried = [];

        if (preset) { try { s.exportAsMediaDirect(outPath, preset, mode);
            var f = new File(outPath); if (f.exists && f.length > 100) return _ok({path:outPath,m:"direct",preset:preset});
            tried.push("direct+preset: empty"); } catch(e) { tried.push("direct+preset: "+e.toString().substring(0,80)); } }

        try { s.exportAsMediaDirect(outPath, "", mode);
            var f = new File(outPath); if (f.exists && f.length > 100) return _ok({path:outPath,m:"direct_default"});
            tried.push("direct_default: empty"); } catch(e) { tried.push("direct_default: "+e.toString().substring(0,80)); }

        if (preset) { try { app.encoder.launchEncoder();
            app.encoder.encodeSequence(s, outPath, preset, workOnly?app.encoder.ENCODE_WORK_AREA:app.encoder.ENCODE_ENTIRE, true);
            return _ok({path:outPath,m:"ame",async:true,preset:preset}); } catch(e) { tried.push("ame+preset: "+e.toString().substring(0,80)); } }

        try { app.encoder.launchEncoder();
            app.encoder.encodeSequence(s, outPath, "", workOnly?app.encoder.ENCODE_WORK_AREA:app.encoder.ENCODE_ENTIRE, true);
            return _ok({path:outPath,m:"ame_default",async:true}); } catch(e) { tried.push("ame_default: "+e.toString().substring(0,80)); }

        return _er("ייצוא נכשל.\n"+tried.join("\n"));
    } catch(e) { return _er(e.toString()); }
}

/* ── Import SRT ────────────────────────────────────────── */
function importSRT(srtPath, startSec) {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף");
        if (!(new File(srtPath)).exists) return _er("קובץ לא נמצא");
        app.project.importFiles([srtPath], true, app.project.rootItem, false);
        var item = null, fname = srtPath.split(/[\/\\]/).pop(), root = app.project.rootItem;
        for (var i = 0; i < root.children.numItems; i++) {
            var it = root.children[i]; if (!it) continue;
            try { if (it.getMediaPath().indexOf(srtPath) !== -1) { item = it; break; } } catch(e) {}
            if (!item && it.name === fname) item = it;
        }
        if (!item) return _ok({ placed: false, note: "SRT יובא לפרויקט — גרור לשורת Caption" });
        try { var t = new Time(); t.seconds = parseFloat(startSec) || 0; item.insertClipAt(s, t, false); return _ok({ placed: true }); }
        catch(e) { return _ok({ placed: false, note: "SRT יובא לפרויקט" }); }
    } catch(e) { return _er(e.toString()); }
}
