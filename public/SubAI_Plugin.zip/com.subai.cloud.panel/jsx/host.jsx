/* host.jsx — SubAI v2.0 — MOGRT Caption Placement */

function _ok(o) {
    var r = { ok: true };
    for (var k in o) r[k] = o[k];
    return JSON.stringify(r);
}
function _er(m) { return JSON.stringify({ ok: false, e: String(m) }); }

function _seq() {
    var s = null;
    try { s = app.project.activeSequence; } catch(e) {}
    if (!s) {
        try {
            if (app.project.sequences && app.project.sequences.numSequences > 0)
                s = app.project.sequences[0];
        } catch(e) {}
    }
    return s;
}

function getSeq() {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף פעיל — דאבל-קליק על רצף בפאנל Project");
        var tb  = parseFloat(s.timebase) || 1;
        var dur = parseFloat(s.end) / tb;
        if (isNaN(dur) || dur <= 0) dur = 0;
        var i = 0, o = dur, BIG = 4503599627370000;
        try { var t = s.getInPointAsTime(); if (t && typeof t.seconds !== 'undefined' && t.seconds >= 0 && t.seconds < dur) i = t.seconds; } catch(e) {}
        try { var t = s.getOutPointAsTime(); if (t && typeof t.seconds !== 'undefined' && t.seconds > 0 && t.seconds <= dur) o = t.seconds; } catch(e) {}
        if (i === 0 && o === dur) {
            try { var r = parseFloat(s.getInPoint()); if (!isNaN(r) && r > 0 && r < BIG) { var v = r / 254016000000; i = (v < dur) ? v : r / tb; if (i >= dur) i = 0; } } catch(e) {}
            try { var r = parseFloat(s.getOutPoint()); if (!isNaN(r) && r > 0 && r < BIG) { var v = r / 254016000000; o = (v <= dur * 1.1) ? v : r / tb; if (o > dur) o = dur; } } catch(e) {}
        }
        if (o <= i) { i = 0; o = dur; }
        var fps = 25;
        try { var st = s.getSettings(); if (st.videoFrameRate && st.videoFrameRate.seconds > 0) fps = Math.round(1 / st.videoFrameRate.seconds); } catch(e) {}
        var hasWA = (o - i) > 0.5 && (i > 0.5 || (dur - o) > 0.5);
        return _ok({ name: s.name || "רצף", dur: Math.round(dur*1000)/1000, fps: fps,
            i: Math.round(i*1000)/1000, o: Math.round(o*1000)/1000, hasWA: hasWA });
    } catch(e) { return _er(e.toString()); }
}

function getInOut() {
    try {
        var s = _seq(); if (!s) return _er("no seq");
        var tb = parseFloat(s.timebase) || 1;
        var dur = parseFloat(s.end) / tb;
        var i = 0, o = dur, BIG = 4503599627370000;
        try { var t = s.getInPointAsTime(); if (t && t.seconds >= 0 && t.seconds < dur) i = t.seconds; } catch(e) {}
        try { var t = s.getOutPointAsTime(); if (t && t.seconds > 0 && t.seconds <= dur) o = t.seconds; } catch(e) {}
        if (i === 0 && o === dur) {
            try { var r = parseFloat(s.getInPoint()); if (r > 0 && r < BIG) { var v = r / 254016000000; i = (v < dur) ? v : r / tb; if (i >= dur) i = 0; } } catch(e) {}
            try { var r = parseFloat(s.getOutPoint()); if (r > 0 && r < BIG) { var v = r / 254016000000; o = (v <= dur * 1.1) ? v : r / tb; if (o > dur) o = dur; } } catch(e) {}
        }
        if (o <= i) { i = 0; o = dur; }
        var hasWA = (o - i) > 0.5 && (i > 0.5 || (dur - o) > 0.5);
        return _ok({ i: Math.round(i*1000)/1000, o: Math.round(o*1000)/1000, hasWA: hasWA, dur: Math.round(dur*1000)/1000 });
    } catch(e) { return _er(e.toString()); }
}

/* ── Audio tracks ── */
function getAudioTracks() {
    try {
        var s = _seq(); if (!s) return _er("no seq");
        var tracks = [];
        for (var t = 0; t < s.audioTracks.numTracks; t++) {
            var track = s.audioTracks[t];
            var clipCount = 0, clipNames = [];
            try { clipCount = track.clips.numItems;
                for (var c = 0; c < Math.min(track.clips.numItems, 3); c++) { try { clipNames.push(track.clips[c].name); } catch(e) {} }
            } catch(e) {}
            tracks.push({ index: t, name: track.name || ("A" + (t+1)), muted: track.isMuted(), clipCount: clipCount, clipNames: clipNames });
        }
        return _ok({ tracks: tracks });
    } catch(e) { return _er(e.toString()); }
}

function soloAudioTrack(soloIndex) {
    try {
        var s = _seq(); if (!s) return _er("no seq");
        var states = [];
        for (var t = 0; t < s.audioTracks.numTracks; t++) {
            states.push(s.audioTracks[t].isMuted());
            s.audioTracks[t].setMute(t === soloIndex ? 0 : 1);
        }
        return _ok({ solo: soloIndex, originalStates: states });
    } catch(e) { return _er(e.toString()); }
}

function restoreTrackMutes(statesJson) {
    try {
        var s = _seq(); if (!s) return _er("no seq");
        var states = JSON.parse(statesJson);
        for (var t = 0; t < Math.min(states.length, s.audioTracks.numTracks); t++) {
            s.audioTracks[t].setMute(states[t] ? 1 : 0);
        }
        return _ok({});
    } catch(e) { return _er(e.toString()); }
}

/* ── Preset scanner ── */
function _scanEPR(folder, depth, results) {
    if (depth > 3 || !folder || !folder.exists) return;
    var items = folder.getFiles(); if (!items) return;
    for (var i = 0; i < items.length; i++) {
        var it = items[i];
        if (it instanceof File && it.name.match(/\.epr$/i)) results.push(it.fsName);
        else if (it instanceof Folder && depth < 3) _scanEPR(it, depth + 1, results);
    }
}
function _pickAudioPreset(list) {
    var pri = [/wav/i, /aiff/i, /audio/i, /flac/i, /mp3/i, /match.?source/i];
    for (var p = 0; p < pri.length; p++) for (var i = 0; i < list.length; i++) if (pri[p].test(list[i])) return list[i];
    return list.length > 0 ? list[0] : "";
}
function findPreset(custom) {
    if (custom) { var f = new File(custom); if (f.exists) return custom; }
    var all = [];
    try { var sp = new Folder(app.path + "/MediaIO/systempresets"); if (sp.exists) _scanEPR(sp, 0, all); } catch(e) {}
    try { var b = new Folder(app.path); if (b.parent) { var sp2 = new Folder(b.parent.fsName + "/MediaIO/systempresets"); if (sp2.exists) _scanEPR(sp2, 0, all); } } catch(e) {}
    return _pickAudioPreset(all);
}

/* ── Export audio ── */
function exportAudio(outPath, presetPath, workOnly) {
    try {
        var s = _seq(); if (!s) return _er("אין רצף פעיל");
        var preset = findPreset(presetPath);
        var mode = workOnly ? 2 : 1;
        var tried = [];
        if (preset) { try { s.exportAsMediaDirect(outPath, preset, mode); var f = new File(outPath); if (f.exists && f.length > 100) return _ok({path:outPath, m:"direct"}); tried.push("direct: empty"); } catch(e) { tried.push("direct: " + e.toString().substring(0,50)); } }
        try { s.exportAsMediaDirect(outPath, "", mode); var f = new File(outPath); if (f.exists && f.length > 100) return _ok({path:outPath, m:"default"}); tried.push("default: empty"); } catch(e) { tried.push("default: " + e.toString().substring(0,50)); }
        if (preset) { try { app.encoder.launchEncoder(); app.encoder.encodeSequence(s, outPath, preset, workOnly?app.encoder.ENCODE_WORK_AREA:app.encoder.ENCODE_ENTIRE, true); return _ok({path:outPath, m:"ame", async:true}); } catch(e) { tried.push("ame: " + e.toString().substring(0,50)); } }
        try { app.encoder.launchEncoder(); app.encoder.encodeSequence(s, outPath, "", workOnly?app.encoder.ENCODE_WORK_AREA:app.encoder.ENCODE_ENTIRE, true); return _ok({path:outPath, m:"ame_default", async:true}); } catch(e) { tried.push("ame_default: " + e.toString().substring(0,50)); }
        return _er("ייצוא נכשל.\n" + tried.join("\n"));
    } catch(e) { return _er(e.toString()); }
}

/* ═══════════════════════════════════════════════════════════════
   MOGRT CAPTION SYSTEM — Places subtitles directly on timeline
   ═══════════════════════════════════════════════════════════════ */

/* Find the MOGRT template file */
function _findMogrt(extPath) {
    // Look in plugin's mogrt folder
    var paths = [];
    if (extPath) {
        paths.push(extPath + "/mogrt/subtitle.mogrt");
        paths.push(extPath + "/mogrt/SubAI_Caption.mogrt");
    }
    // Also check common locations
    var home = Folder.userData ? Folder.userData.fsName : "";
    if (home) {
        paths.push(home + "/Adobe/Common/Essential Graphics/SubAI_Caption.mogrt");
    }
    for (var i = 0; i < paths.length; i++) {
        var f = new File(paths[i]);
        if (f.exists) return paths[i];
    }
    return null;
}

/*
   placeCaptions — Main function called from plugin
   segmentsJson: JSON string of [{start, end, text}, ...]
   extPath: path to extension folder (for finding MOGRT)
   trackIdx: video track index to place captions (-1 = last track or new)

   Uses 3 methods in priority order:
   1. MOGRT import (if template exists)
   2. QE DOM graphics creation
   3. SRT import fallback
*/
function placeCaptions(segmentsJson, extPath, trackIdx) {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף");

        var segments = JSON.parse(segmentsJson);
        if (!segments || segments.length === 0) return _er("אין כתוביות");

        trackIdx = parseInt(trackIdx);
        if (isNaN(trackIdx) || trackIdx < 0) trackIdx = s.videoTracks.numTracks - 1;

        // Ensure we have a track to work with
        var track = s.videoTracks[trackIdx];
        if (!track) return _er("Track not found: " + trackIdx);

        var placed = 0;
        var method = "unknown";
        var errors = [];

        // ── METHOD 1: MOGRT Template ────────────────────────────
        var mogrtPath = _findMogrt(extPath);
        if (mogrtPath) {
            try {
                for (var i = 0; i < segments.length; i++) {
                    var seg = segments[i];
                    var startTime = new Time();
                    startTime.seconds = seg.start;

                    var endTime = new Time();
                    endTime.seconds = seg.end;

                    // Import MOGRT at position
                    var mogrtItem = s.importMOGRT(
                        mogrtPath,
                        startTime,
                        trackIdx
                    );

                    if (mogrtItem) {
                        // Set duration
                        mogrtItem.end = endTime;

                        // Set text property — try multiple paths
                        try {
                            var components = mogrtItem.components;
                            for (var c = 0; c < components.numItems; c++) {
                                var comp = components[c];
                                for (var p = 0; p < comp.properties.numItems; p++) {
                                    var prop = comp.properties[p];
                                    if (prop.displayName === "Source Text" ||
                                        prop.displayName === "Text" ||
                                        prop.displayName === "Caption Text" ||
                                        prop.displayName === "טקסט") {
                                        prop.setValue(seg.text);
                                        break;
                                    }
                                }
                            }
                        } catch(te) {}

                        placed++;
                    }
                }
                method = "mogrt";
                if (placed > 0) return _ok({ placed: placed, total: segments.length, method: method });
            } catch(e) {
                errors.push("mogrt: " + e.toString().substring(0, 60));
            }
        }

        // ── METHOD 2: QE DOM Graphics ───────────────────────────
        try {
            var qeSeq = qe.project.getActiveSequence();
            if (qeSeq) {
                var qeTrack = qeSeq.getVideoTrackAt(trackIdx);
                if (qeTrack) {
                    for (var i = 0; i < segments.length; i++) {
                        var seg = segments[i];
                        var ticks = Math.round(seg.start * 254016000000).toString();
                        var durTicks = Math.round((seg.end - seg.start) * 254016000000).toString();

                        try {
                            // Create a new graphics clip
                            qeTrack.addNewGraphicsClip(ticks);

                            // Get the last added clip and set its text
                            var numClips = qeTrack.numItems;
                            if (numClips > 0) {
                                var clip = qeTrack.getItemAt(numClips - 1);
                                if (clip) {
                                    // Set text via QE
                                    try {
                                        clip.name = seg.text;
                                    } catch(ne) {}
                                    placed++;
                                }
                            }
                        } catch(qe2) {
                            // Try alternative QE method
                            try {
                                qeTrack.addTransition(ticks);
                                placed++;
                            } catch(qe3) {}
                        }
                    }
                    method = "qe_graphics";
                    if (placed > 0) return _ok({ placed: placed, total: segments.length, method: method });
                }
            }
        } catch(e) {
            errors.push("qe: " + e.toString().substring(0, 60));
        }

        // ── METHOD 3: SRT Import Fallback ───────────────────────
        // Build SRT from segments and import
        try {
            var srtContent = "";
            for (var i = 0; i < segments.length; i++) {
                var seg = segments[i];
                srtContent += (i + 1) + "\n";
                srtContent += _ts(seg.start) + " --> " + _ts(seg.end) + "\n";
                srtContent += seg.text + "\n\n";
            }

            // Write SRT file
            var tmp = Folder.temp.fsName + "/subai_" + Date.now() + ".srt";
            var f = new File(tmp);
            f.encoding = "UTF-8";
            f.open("w");
            f.write(srtContent);
            f.close();

            // Import to project
            app.project.importFiles([tmp], true, app.project.rootItem, false);

            // Try to insert into timeline
            var item = null;
            var fname = tmp.split(/[\/\\]/).pop();
            var root = app.project.rootItem;
            for (var j = root.children.numItems - 1; j >= 0; j--) {
                var it = root.children[j];
                if (it && it.name === fname) { item = it; break; }
            }

            if (item) {
                try {
                    var startTime = new Time();
                    startTime.seconds = segments[0].start;
                    s.insertClip(item, startTime);
                    placed = segments.length;
                    method = "srt_insert";
                } catch(ie) {
                    placed = segments.length;
                    method = "srt_project";
                }
            }

            return _ok({ placed: placed, total: segments.length, method: method, srtPath: tmp });
        } catch(e) {
            errors.push("srt: " + e.toString().substring(0, 60));
        }

        return _er("לא הצלחתי למקם כתוביות.\n" + errors.join("\n"));
    } catch(e) { return _er(e.toString()); }
}

/* Helper: seconds to SRT timestamp */
function _ts(sec) {
    sec = Math.max(0, sec);
    var h = Math.floor(sec / 3600);
    var m = Math.floor((sec % 3600) / 60);
    var sc = Math.floor(sec % 60);
    var ms = Math.round((sec - Math.floor(sec)) * 1000);
    return (h < 10 ? "0" : "") + h + ":" + (m < 10 ? "0" : "") + m + ":" + (sc < 10 ? "0" : "") + sc + "," + (ms < 10 ? "00" : ms < 100 ? "0" : "") + ms;
}

/* Legacy SRT import (for backward compatibility) */
function importSRT(srtPath, startSec) {
    try {
        var s = _seq();
        if (!s) return _er("אין רצף");
        if (!(new File(srtPath)).exists) return _er("קובץ לא נמצא");
        app.project.importFiles([srtPath], true, app.project.rootItem, false);
        var item = null, fname = srtPath.split(/[\/\\]/).pop(), root = app.project.rootItem;
        for (var i = root.children.numItems - 1; i >= 0; i--) {
            var it = root.children[i]; if (!it) continue;
            if (it.name === fname) { item = it; break; }
        }
        if (!item) return _ok({ placed: false, note: "SRT יובא לפרויקט" });
        try {
            var t = new Time(); t.seconds = parseFloat(startSec) || 0;
            s.insertClip(item, t);
            return _ok({ placed: true });
        } catch(e) {
            return _ok({ placed: false, note: "SRT יובא לפרויקט — גרור ל-Caption Track" });
        }
    } catch(e) { return _er(e.toString()); }
}
