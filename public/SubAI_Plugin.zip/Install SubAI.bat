@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0Install-SubAI.ps1"
