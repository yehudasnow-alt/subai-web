@echo off
chcp 437 >nul 2>&1
title SubAI Plugin Installer
mode con: cols=60 lines=30
color 0B

echo.
echo    ====================================================
echo    =                                                  =
echo    =           S U B A I   I N S T A L L E R          =
echo    =                                                  =
echo    =       AI Subtitles for Adobe Premiere Pro        =
echo    =                                                  =
echo    ====================================================
echo.
echo.
echo       This will install the SubAI plugin.
echo       Premiere Pro must be installed first.
echo.
echo.
echo    Press any key to start installation...
echo.
pause >nul

cls
color 0B
echo.
echo    ====================================================
echo           S U B A I   I N S T A L L E R
echo    ====================================================
echo.
echo.
echo    [Step 1 of 3] Checking Adobe installation...
echo.

set "APPDATA_PATH=%APPDATA%"
set "EXT_DIR=%APPDATA_PATH%\Adobe\CEP\extensions"
set "PLUGIN_DIR=%EXT_DIR%\com.subai.cloud.panel"

if not exist "%APPDATA_PATH%\Adobe" (
    color 0C
    echo    [ERROR] Adobe folder not found!
    echo.
    echo    Please install Adobe Premiere Pro first.
    echo.
    pause
    exit /b 1
)

echo    [OK] Adobe found!
echo.
echo.
echo    [Step 2 of 3] Enabling plugin support...
echo.

reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1

echo    [OK] Plugin support enabled!
echo.
echo.
echo    [Step 3 of 3] Installing SubAI plugin...
echo.

if not exist "%EXT_DIR%" (
    mkdir "%EXT_DIR%" 2>nul
)

if exist "%PLUGIN_DIR%" (
    echo    Removing previous version...
    rmdir /s /q "%PLUGIN_DIR%" 2>nul
    timeout /t 1 /nobreak >nul
)

set "SRC_DIR=%~dp0com.subai.cloud.panel"

if not exist "%SRC_DIR%" (
    color 0C
    echo    [ERROR] Plugin files not found!
    echo.
    echo    Make sure "com.subai.cloud.panel" folder
    echo    is in the same directory as this installer.
    echo.
    pause
    exit /b 1
)

xcopy "%SRC_DIR%" "%PLUGIN_DIR%" /E /I /Y /Q >nul 2>&1

if exist "%PLUGIN_DIR%\index.html" (
    cls
    color 0A
    echo.
    echo    ====================================================
    echo    =                                                  =
    echo    =        INSTALLATION COMPLETE!                    =
    echo    =                                                  =
    echo    ====================================================
    echo.
    echo.
    echo    SubAI has been installed successfully!
    echo.
    echo    ---- Next Steps: ----
    echo.
    echo    1. Open Adobe Premiere Pro
    echo.
    echo    2. Go to: Window ^> Extensions ^> SubAI
    echo.
    echo    3. Log in with your email and password
    echo.
    echo    4. Select a sequence and click "Transcribe"!
    echo.
    echo.
    echo    Get your account at: subai-web.vercel.app
    echo.
    echo    ====================================================
    echo.
) else (
    color 0C
    echo.
    echo    [ERROR] Installation failed.
    echo    Try right-clicking this file and selecting
    echo    "Run as Administrator"
    echo.
)

echo.
echo    Press any key to close...
pause >nul
