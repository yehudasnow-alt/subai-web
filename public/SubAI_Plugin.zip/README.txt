
  ✨ SubAI Plugin for Premiere Pro ✨
  ====================================

  Installation:
  1. Double-click "Install-SubAI.bat"
  2. Open Premiere Pro
  3. Window → Extensions → SubAI
  4. Paste your API Key (from subai-web.vercel.app/dashboard)
  5. Start transcribing!

  Uninstall:
  Double-click "Uninstall-SubAI.bat"

  Support: https://subai-web.vercel.app

