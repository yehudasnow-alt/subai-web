@echo off
chcp 65001 >nul 2>&1
title SubAI - Uninstaller
color 0C

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║         SubAI Plugin Uninstaller             ║
echo  ╚══════════════════════════════════════════════╝
echo.

set "PLUGIN_DIR=%APPDATA%\Adobe\CEP\extensions\com.subai.cloud.panel"

if exist "%PLUGIN_DIR%" (
    rmdir /s /q "%PLUGIN_DIR%"
    echo  ✅ SubAI plugin removed successfully.
    echo  Restart Premiere Pro to complete uninstallation.
) else (
    echo  Plugin not found - already uninstalled.
)

echo.
pause
