@echo off
title SubAI - Uninstaller
color 0C

echo.
echo  ======================================
echo       SubAI Plugin Uninstaller
echo  ======================================
echo.

set "PLUGIN_DIR=%APPDATA%\Adobe\CEP\extensions\com.subai.cloud.panel"

if exist "%PLUGIN_DIR%" (
    rmdir /s /q "%PLUGIN_DIR%"
    echo  Plugin removed successfully.
    echo  Restart Premiere Pro to complete.
) else (
    echo  Plugin not found - already uninstalled.
)

echo.
pause
