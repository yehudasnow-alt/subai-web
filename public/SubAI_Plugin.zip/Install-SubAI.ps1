Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = "SubAI - Install"
$form.Size = New-Object System.Drawing.Size(480, 360)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(13, 13, 26)
$form.ForeColor = [System.Drawing.Color]::FromArgb(224, 224, 238)
$form.Font = New-Object System.Drawing.Font("Segoe UI", 10)

$title = New-Object System.Windows.Forms.Label
$title.Text = "SubAI Installer"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 20, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::FromArgb(129, 140, 248)
$title.Size = New-Object System.Drawing.Size(460, 40)
$title.Location = New-Object System.Drawing.Point(10, 20)
$title.TextAlign = "MiddleCenter"
$form.Controls.Add($title)

$sub = New-Object System.Windows.Forms.Label
$sub.Text = "AI Subtitles for Adobe Premiere Pro"
$sub.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 160)
$sub.Size = New-Object System.Drawing.Size(460, 24)
$sub.Location = New-Object System.Drawing.Point(10, 62)
$sub.TextAlign = "MiddleCenter"
$form.Controls.Add($sub)

$status = New-Object System.Windows.Forms.Label
$status.Text = "Click Install to begin"
$status.Size = New-Object System.Drawing.Size(440, 24)
$status.Location = New-Object System.Drawing.Point(20, 110)
$status.ForeColor = [System.Drawing.Color]::FromArgb(160, 160, 190)
$form.Controls.Add($status)

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Size = New-Object System.Drawing.Size(440, 8)
$progress.Location = New-Object System.Drawing.Point(20, 140)
$progress.Style = "Continuous"
$progress.ForeColor = [System.Drawing.Color]::FromArgb(59, 130, 246)
$form.Controls.Add($progress)

$log = New-Object System.Windows.Forms.Label
$log.Text = ""
$log.Size = New-Object System.Drawing.Size(440, 80)
$log.Location = New-Object System.Drawing.Point(20, 160)
$log.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 130)
$log.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$form.Controls.Add($log)

$btnInstall = New-Object System.Windows.Forms.Button
$btnInstall.Text = "Install SubAI"
$btnInstall.Size = New-Object System.Drawing.Size(200, 44)
$btnInstall.Location = New-Object System.Drawing.Point(140, 260)
$btnInstall.FlatStyle = "Flat"
$btnInstall.BackColor = [System.Drawing.Color]::FromArgb(59, 130, 246)
$btnInstall.ForeColor = [System.Drawing.Color]::White
$btnInstall.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$btnInstall.FlatAppearance.BorderSize = 0
$btnInstall.Cursor = [System.Windows.Forms.Cursors]::Hand
$form.Controls.Add($btnInstall)

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pluginSrc = Join-Path $scriptDir "com.subai.cloud.panel"
$extDir = Join-Path $env:APPDATA "Adobe\CEP\extensions"
$pluginDst = Join-Path $extDir "com.subai.cloud.panel"

$btnInstall.Add_Click({
    $btnInstall.Enabled = $false
    $btnInstall.Text = "Installing..."

    # Step 1
    $status.Text = "Step 1/3  Checking Adobe..."
    $progress.Value = 20
    $form.Refresh()
    Start-Sleep -Milliseconds 500

    $adobeDir = Join-Path $env:APPDATA "Adobe"
    if (-not (Test-Path $adobeDir)) {
        $status.Text = "ERROR: Adobe not found!"
        $status.ForeColor = [System.Drawing.Color]::FromArgb(248, 113, 113)
        $log.Text = "Install Adobe Premiere Pro first."
        $btnInstall.Text = "Close"
        $btnInstall.Enabled = $true
        $btnInstall.Add_Click({ $form.Close() })
        return
    }
    $log.Text = "Adobe found at $adobeDir"

    # Step 2
    $status.Text = "Step 2/3  Enabling plugin support..."
    $progress.Value = 50
    $form.Refresh()
    Start-Sleep -Milliseconds 400

    @("9","10","11","12") | ForEach-Object {
        $regPath = "HKCU:\Software\Adobe\CSXS.$_"
        if (-not (Test-Path $regPath)) { New-Item -Path $regPath -Force | Out-Null }
        Set-ItemProperty -Path $regPath -Name "PlayerDebugMode" -Value "1" -Type String
    }
    $log.Text = "Debug mode enabled for CSXS 9-12"

    # Step 3
    $status.Text = "Step 3/3  Installing plugin files..."
    $progress.Value = 75
    $form.Refresh()
    Start-Sleep -Milliseconds 400

    if (-not (Test-Path $pluginSrc)) {
        $status.Text = "ERROR: Plugin files not found!"
        $status.ForeColor = [System.Drawing.Color]::FromArgb(248, 113, 113)
        $log.Text = "Keep com.subai.cloud.panel folder next to installer."
        $btnInstall.Text = "Close"
        $btnInstall.Enabled = $true
        return
    }

    if (-not (Test-Path $extDir)) { New-Item -Path $extDir -ItemType Directory -Force | Out-Null }
    if (Test-Path $pluginDst) { Remove-Item -Path $pluginDst -Recurse -Force }
    Copy-Item -Path $pluginSrc -Destination $pluginDst -Recurse -Force

    $progress.Value = 100
    $status.Text = "Installation Complete!"
    $status.ForeColor = [System.Drawing.Color]::FromArgb(52, 211, 153)
    $title.ForeColor = [System.Drawing.Color]::FromArgb(52, 211, 153)
    $log.Text = "1. Open Premiere Pro`n2. Window > Extensions > SubAI`n3. Login with Google`n4. Mark In/Out and transcribe!"

    $btnInstall.Text = "Done"
    $btnInstall.BackColor = [System.Drawing.Color]::FromArgb(52, 211, 153)
    $btnInstall.Enabled = $true
    $btnInstall.Add_Click({ $form.Close() })
})

$form.ShowDialog()
