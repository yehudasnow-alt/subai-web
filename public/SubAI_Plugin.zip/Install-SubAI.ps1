Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$icoPath = Join-Path $scriptDir "SubAI.ico"

# ── Form ──
$form = New-Object System.Windows.Forms.Form
$form.Text = "SubAI Installer"
$form.Size = New-Object System.Drawing.Size(500, 400)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(12, 12, 20)
$form.ForeColor = [System.Drawing.Color]::White
$form.Font = New-Object System.Drawing.Font("Segoe UI", 10)
if (Test-Path $icoPath) { $form.Icon = New-Object System.Drawing.Icon($icoPath) }

# ── Header gradient panel ──
$header = New-Object System.Windows.Forms.Panel
$header.Size = New-Object System.Drawing.Size(500, 90)
$header.Location = New-Object System.Drawing.Point(0, 0)
$header.BackColor = [System.Drawing.Color]::FromArgb(16, 16, 32)
$form.Controls.Add($header)

# ── Logo icon ──
if (Test-Path $icoPath) {
    $logoPic = New-Object System.Windows.Forms.PictureBox
    $logoPic.Size = New-Object System.Drawing.Size(50, 50)
    $logoPic.Location = New-Object System.Drawing.Point(20, 20)
    $logoPic.SizeMode = "Zoom"
    $logoPic.Image = [System.Drawing.Image]::FromFile((Join-Path $scriptDir "logo.png"))
    $header.Controls.Add($logoPic)
}

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = "SubAI Installer"
$titleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 18, [System.Drawing.FontStyle]::Bold)
$titleLabel.ForeColor = [System.Drawing.Color]::White
$titleLabel.Size = New-Object System.Drawing.Size(380, 32)
$titleLabel.Location = New-Object System.Drawing.Point(80, 18)
$header.Controls.Add($titleLabel)

$subLabel = New-Object System.Windows.Forms.Label
$subLabel.Text = "AI Subtitles for Adobe Premiere Pro"
$subLabel.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$subLabel.ForeColor = [System.Drawing.Color]::FromArgb(140, 140, 180)
$subLabel.Size = New-Object System.Drawing.Size(380, 22)
$subLabel.Location = New-Object System.Drawing.Point(80, 52)
$header.Controls.Add($subLabel)

# ── Separator ──
$sep = New-Object System.Windows.Forms.Panel
$sep.Size = New-Object System.Drawing.Size(500, 2)
$sep.Location = New-Object System.Drawing.Point(0, 90)
$sep.BackColor = [System.Drawing.Color]::FromArgb(59, 130, 246)
$form.Controls.Add($sep)

# ── Status ──
$status = New-Object System.Windows.Forms.Label
$status.Text = "Ready to install SubAI plugin"
$status.Font = New-Object System.Drawing.Font("Segoe UI", 11)
$status.Size = New-Object System.Drawing.Size(460, 28)
$status.Location = New-Object System.Drawing.Point(20, 110)
$status.ForeColor = [System.Drawing.Color]::FromArgb(200, 200, 220)
$form.Controls.Add($status)

# ── Progress ──
$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Size = New-Object System.Drawing.Size(460, 6)
$progress.Location = New-Object System.Drawing.Point(20, 145)
$progress.Style = "Continuous"
$form.Controls.Add($progress)

# ── Step labels ──
$step1 = New-Object System.Windows.Forms.Label
$step1.Text = "   Detect Adobe Premiere Pro"
$step1.Size = New-Object System.Drawing.Size(460, 22)
$step1.Location = New-Object System.Drawing.Point(20, 170)
$step1.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 130)
$form.Controls.Add($step1)

$step2 = New-Object System.Windows.Forms.Label
$step2.Text = "   Enable plugin support"
$step2.Size = New-Object System.Drawing.Size(460, 22)
$step2.Location = New-Object System.Drawing.Point(20, 195)
$step2.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 130)
$form.Controls.Add($step2)

$step3 = New-Object System.Windows.Forms.Label
$step3.Text = "   Install SubAI plugin"
$step3.Size = New-Object System.Drawing.Size(460, 22)
$step3.Location = New-Object System.Drawing.Point(20, 220)
$step3.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 130)
$form.Controls.Add($step3)

# ── Info after install ──
$info = New-Object System.Windows.Forms.Label
$info.Text = ""
$info.Size = New-Object System.Drawing.Size(460, 60)
$info.Location = New-Object System.Drawing.Point(20, 255)
$info.ForeColor = [System.Drawing.Color]::FromArgb(160, 160, 190)
$info.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$form.Controls.Add($info)

# ── Install Button ──
$btnInstall = New-Object System.Windows.Forms.Button
$btnInstall.Text = "Install"
$btnInstall.Size = New-Object System.Drawing.Size(220, 48)
$btnInstall.Location = New-Object System.Drawing.Point(140, 330)
$btnInstall.FlatStyle = "Flat"
$btnInstall.BackColor = [System.Drawing.Color]::FromArgb(59, 130, 246)
$btnInstall.ForeColor = [System.Drawing.Color]::White
$btnInstall.Font = New-Object System.Drawing.Font("Segoe UI", 13, [System.Drawing.FontStyle]::Bold)
$btnInstall.FlatAppearance.BorderSize = 0
$btnInstall.Cursor = [System.Windows.Forms.Cursors]::Hand
$form.Controls.Add($btnInstall)

# ── Paths ──
$pluginSrc = Join-Path $scriptDir "com.subai.cloud.panel"
$extDir = Join-Path $env:APPDATA "Adobe\CEP\extensions"
$pluginDst = Join-Path $extDir "com.subai.cloud.panel"

$btnInstall.Add_Click({
    $btnInstall.Enabled = $false
    $btnInstall.Text = "Installing..."
    $btnInstall.BackColor = [System.Drawing.Color]::FromArgb(40, 90, 180)

    # Step 1 — Check Adobe
    $step1.Text = ">> Checking Adobe..."
    $step1.ForeColor = [System.Drawing.Color]::FromArgb(129, 140, 248)
    $status.Text = "Step 1/3 — Detecting Adobe Premiere Pro"
    $progress.Value = 25
    $form.Refresh()
    Start-Sleep -Milliseconds 600

    if (-not (Test-Path (Join-Path $env:APPDATA "Adobe"))) {
        $step1.Text = "X  Adobe not found!"
        $step1.ForeColor = [System.Drawing.Color]::FromArgb(248, 113, 113)
        $status.Text = "Error: Install Adobe Premiere Pro first"
        $status.ForeColor = [System.Drawing.Color]::FromArgb(248, 113, 113)
        $info.Text = "Download Premiere Pro from adobe.com"
        $btnInstall.Text = "Close"
        $btnInstall.BackColor = [System.Drawing.Color]::FromArgb(80, 40, 40)
        $btnInstall.Enabled = $true
        $script:closeMode = $true
        return
    }
    $step1.Text = "V  Adobe Premiere Pro found"
    $step1.ForeColor = [System.Drawing.Color]::FromArgb(52, 211, 153)

    # Step 2 — Enable plugins
    $step2.Text = ">> Enabling plugin support..."
    $step2.ForeColor = [System.Drawing.Color]::FromArgb(129, 140, 248)
    $status.Text = "Step 2/3 — Configuring Adobe CEP"
    $progress.Value = 50
    $form.Refresh()
    Start-Sleep -Milliseconds 500

    @("9","10","11","12") | ForEach-Object {
        $regPath = "HKCU:\Software\Adobe\CSXS.$_"
        if (-not (Test-Path $regPath)) { New-Item -Path $regPath -Force | Out-Null }
        Set-ItemProperty -Path $regPath -Name "PlayerDebugMode" -Value "1" -Type String
    }
    $step2.Text = "V  Plugin support enabled"
    $step2.ForeColor = [System.Drawing.Color]::FromArgb(52, 211, 153)

    # Step 3 — Install plugin
    $step3.Text = ">> Installing plugin files..."
    $step3.ForeColor = [System.Drawing.Color]::FromArgb(129, 140, 248)
    $status.Text = "Step 3/3 — Copying plugin files"
    $progress.Value = 75
    $form.Refresh()
    Start-Sleep -Milliseconds 500

    if (-not (Test-Path $pluginSrc)) {
        $step3.Text = "X  Plugin files not found!"
        $step3.ForeColor = [System.Drawing.Color]::FromArgb(248, 113, 113)
        $status.Text = "Error: Missing plugin folder"
        $status.ForeColor = [System.Drawing.Color]::FromArgb(248, 113, 113)
        $btnInstall.Text = "Close"
        $btnInstall.Enabled = $true
        $script:closeMode = $true
        return
    }

    if (-not (Test-Path $extDir)) { New-Item -Path $extDir -ItemType Directory -Force | Out-Null }
    if (Test-Path $pluginDst) { Remove-Item -Path $pluginDst -Recurse -Force }
    Copy-Item -Path $pluginSrc -Destination $pluginDst -Recurse -Force

    $progress.Value = 100
    $step3.Text = "V  Plugin installed successfully!"
    $step3.ForeColor = [System.Drawing.Color]::FromArgb(52, 211, 153)

    $status.Text = "Installation Complete!"
    $status.ForeColor = [System.Drawing.Color]::FromArgb(52, 211, 153)
    $status.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)

    $info.Text = "Next steps:`n1. Open Adobe Premiere Pro`n2. Window > Extensions > SubAI`n3. Login with Google and start transcribing!"
    $info.ForeColor = [System.Drawing.Color]::FromArgb(200, 200, 220)

    $btnInstall.Text = "Done"
    $btnInstall.BackColor = [System.Drawing.Color]::FromArgb(52, 211, 153)
    $btnInstall.Enabled = $true
    $script:closeMode = $true
})

$script:closeMode = $false
$btnInstall.Add_Click({
    if ($script:closeMode) { $form.Close() }
})

$form.ShowDialog()
